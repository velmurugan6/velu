package beginner;

public class Pyramid {

	public static void main(String[] args) {
		int i=0;
		do
		{  
         int j=0;
             while(j<(5-i))
             {
        	 System.out.print(" ");
        	 j++;
             }
             int k=0;
             while(k<=i)
             {
        	 System.out.print("* ");
        	 k++;
             }
             System.out.println("");
		 i++;
	    }while(i<5);

   }
}