package beginner;

public class namingconventions {
	

}
