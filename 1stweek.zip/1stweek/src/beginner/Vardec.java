package beginner;

public class Vardec {

		     public static void main(String args[]) {
		          byte maxByte = Byte.MAX_VALUE;
		          short maxShort = Short.MAX_VALUE;
		          int maxInteger = Integer.MAX_VALUE;
		          long maxLong = Long.MAX_VALUE;
		         float maxFloat = Float.MAX_VALUE;
		         double maxDouble = Double.MAX_VALUE;
		        System.out.println("largest byte value is " + maxByte + ".");
		        System.out.println("largest short value is " + maxShort + ".");
		        System.out.println("largest integer value is " + maxInteger + ".");
		        System.out.println("largest long value is " + maxLong + ".");
		        System.out.println("largest float value is " + maxFloat + ".");
		        System.out.println("largest double value is " + maxDouble + ".");
		   }
		}
	

	
