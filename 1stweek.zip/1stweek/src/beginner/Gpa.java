package beginner;

import java.io.IOException;
import java.util.Scanner;

public class Gpa {

	private static Scanner read;

	public static void main(String[] args) throws IOException{
		
		float n,inter,medium;
		{
			System.out.println("Enter the old gpa ");
			read = new Scanner(System.in);
			n= read.nextFloat();
			
				System.out.println("Enter the current cgpa");
				float centi=read.nextFloat();
				System.out.println("Enter the semester");
				float met=read.nextFloat();
				if(centi<=met)
					inter=n-centi;
				else
					inter=centi-n;
				medium=inter/n;  
				
				System.out.println("New Gpa is"+(medium+n));

		}
	}
}	