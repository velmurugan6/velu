package beginner;

import java.util.Scanner;

public class ExceptionHandling {

	Scanner scan = new Scanner(System.in);

	public void arithmeticException() {
		System.out.println("Arithmetic Exception ");
		try {
			@SuppressWarnings("resource")
			Scanner scan = new Scanner(System.in);
			int a, b;
			System.out.println("Enter first number");
			a = scan.nextInt();
			System.out.println("Enter second number");
			b = scan.nextInt();
			int c = a / b;
			System.out.println(c);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public void arrayException() {
		System.out.println("Array Index Out of Bound Exception");
		try {

			int[] a = new int[5];
			System.out.println("Enter the 5 values");
			for (int i = 0; i < 6; i++) {
				a[i] = scan.nextInt();
			}
			System.out.println("Elements has been entered");
		} catch (Exception e) {
			System.out.println("e");
		}
	}

	public void nullPointerException() {
		System.out.println("Null Pointer Exception");
		try {
			System.out.println("The value of string is null");
			String str = null;
			System.out.println(str.length());
		} catch (Exception e) {
			System.out.println(e);

		}
	}

	public void formatExpception() {
		System.out.println("Number format Exception");
		try {
			System.out.println("Enter an number");

			int num = Integer.parseInt(scan.next());
			System.out.println(num);
		} catch (Exception e) {
			System.out.println("Number format exception occurred"+e);
		}
	}

	public void stringException() {
		System.out.println("String Index Out Of Bounds Exception");
		try {
			System.out.println("Enter an String");
			String str = scan.next();
			System.out.println("The length of the string");
			System.out.println(str.length());
			;
			char c = str.charAt(0);
			c = str.charAt(40);
			System.out.println(c);
		} catch (Exception e) {
			System.out.println("String Index Out O fBounds Exception Occured");
		}
	}

	public static void main(String[] args) {

		int choice = 0;
		do {
			try {
				ExceptionHandling ex = new ExceptionHandling();
				System.out.println("1.Arithmetic Exception");
				System.out.println("2.Array Index Out of Bound Exception");
				System.out.println("3.Null Pointer Exception");
				System.out.println("4.Number format Exception");
				System.out.println("5.String Index Out Of Bounds Exception");
				System.out.println("6.Exit");
				Scanner scan = new Scanner(System.in);
				choice = scan.nextInt();
				switch (choice) {
				case 1: {
					ex.arithmeticException();
					break;
				}
				case 2: {
					ex.arrayException();
					break;
				}
				case 3: {
					ex.nullPointerException();
					break;
				}
				case 4: {
					ex.formatExpception();
					break;
				}
				case 5: {
					ex.stringException();
					break;
				}
				case 6: {
					System.out.println("You are exited");
					break;
				}
				default: {
					System.out.println("You entered Invalid number");
				}
				}
			} catch (Exception e) {
				System.out.println("Invalid Input");
			}
		} while (choice < 6);

	}
}
