package beginner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class marklist {
		
			String[] name;
			int n;
			int[] roll_no;
			int[] sub;
			int[] eng;
			int[] total;
			float[] per;
			int i;
			void getdata() throws IOException
			{
				for(i=0;i<3;i++)
				{
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("Enter the no of students");
				n=Integer.parseInt(br.readLine());
	        	System.out.println ("Enter Name of Student");
				name[i] = br.readLine();
				System.out.println ("Enter Roll No. of Student");
				roll_no[i] = Integer.parseInt(br.readLine());
				System.out.println ("Enter marks out of 100 of 1st subject");
				sub[i] = Integer.parseInt(br.readLine());
				System.out.println ("Enter marks out of 100 of 2nd subject");
				eng[i] = Integer.parseInt(br.readLine());
				}
			for(i=0;i<n;i++)
			{
				total[i]=sub[i]+eng[i];
				per[i]=(total[i]*100)/200;
				
				System.out.println ("Roll No. = "+roll_no[i]);
				System.out.println ("Name = "+name[i]);
				System.out.println ("Marks of 1st Subject = "+sub[i]);
				System.out.println ("Marks of 2nd Subject = "+eng[i]);
				System.out.println ("Total Marks = "+total[i]);
				System.out.println ("Percentage = "+per[i]+"%");
			}
			}
		
		
			public static void main(String args[]) throws IOException
			{
				marklist s=new marklist();
				s.getdata();
			
			}
		}

	
