package beginner;

import java.util.*;

class Override {
	public void pyramid(int length, String name) {
		int row = 0;
		do {
			int column = 0;
			while (column < (length - row)) {
				System.out.print(" ");
				column++;
			}
			int position = 0;
			while (position <= row) {
				char c = name.charAt(position);
				System.out.print(c + " ");
				position++;
			}
			System.out.println("");
			row++;
		} while (row < length);
	}

	public void triangle(int length, String name) {
		int row = 0;
		do {
			int column = 0;
			while (column < (length - row)) {
				System.out.print("");
				column++;
			}
			int position = 0;
			while (position <= row) {
				char c = name.charAt(position);
				System.out.print(c + " ");
				position++;
			}
			System.out.println("");
			row++;
		} while (row < length);
	}

	public static void main(String args[]) {

		Override obj = new Override();
		Scanner word = new Scanner(System.in);
		System.out.println("\nEnter the name \n");
		String name = word.nextLine();
		int length = name.length();
		System.out.println("\nLength of the name\n \n" + length + "\n\n");
		int i = ((length % 2) == 0 ? 0 : 1);
		if (i == 0)
			obj.pyramid(length, name);
		if (i == 1)
			obj.triangle(length, name);

		word.close();

	}
}