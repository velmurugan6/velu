package beginner;

import java.util.Scanner;

public class Multiplication {
	private static Scanner s;

	public static void main(String[] args){
		int j;
	do{System.out.println("Enter the table u want... to quit press 0");
		
		s = new Scanner(System.in);
		j=s.nextInt();
		if(j==0)
			break;
			for(int i=1;i<=10;i++)
			{
				System.out.println(j+" * "+i+" = "+(i*j));
			}
			System.out.println("\n\n");
		}while(j!=0);
	}
}


