package beginner;

import java.util.Scanner;


public class Calculator {
	
    void add(int a,int b, int c)
    {
    	System.out.println(a+b+c);
    }
    void add(int a,int b)
    {
    	System.out.println(a+b);
    }
    void sub(int a,int b)
    {
    	System.out.println(a-b);
    }
    void mul(int a,int b,int c)
    {
    	System.out.println(a*b*c);

    }
    void mul(int a,int b)
    {
    	System.out.println(a*b);

    }
    void div(int a,int b)
    {
    	System.out.println(a/b);
    }
	public static void main(String[] args) {
		{int c1 = 0,opt;
			Calculator ob=new Calculator();
			do
			{
		    	System.out.println("1.Add 2num\n2.Add 3num\n3.Sub\n4.Mul 2 num\n5.Mul 3 num\n6.Div\n7.Exit ");
		    	Scanner sc=new Scanner(System.in);
		    	 opt=sc.nextInt();
		    	 if(opt==7)
		    		 break;
		    	System.out.println("Enter the first number");
		    	int a1=sc.nextInt();
		    	System.out.println("Enter the second number");
		    	int b1=sc.nextInt();
		    	if(opt==2||opt==5)
		    	{
		        	System.out.println("Enter the third number");
		    		c1=sc.nextInt();
		    	}
		    	switch(opt)
		    	{
		    	case 1:
		    		ob.add(a1,b1);
		    		break;
		    	case 2:
		    		ob.add(a1, b1,c1);
		    		break;
		    	case 3:
		    		ob.sub(a1,b1);
		    		break;
		    	case 4:
		    		ob.mul(a1, b1);
		    		break;
		    	case 5:
		    		ob.mul(a1, b1,c1);
		    		break;
		    	case 6:
		    		ob.div(a1, b1);
		    		break;
		    		
		    	}
		    	sc.close();
		    	}while(opt<7);
			}
		}
		

	}


