package beginner;

import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		String name;
		int n,i;
		System.out.println("Enter your name");
		Scanner obj=new Scanner(System.in);
		name=obj.nextLine();
		n=name.length();
		for(i=n-1;i>=0;i--)
		System.out.print(name.charAt(i));
		
		obj.close();

	}

}
