package beginner;

public class echo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  for(String s:args)
  {
	  System.out.println(s);
	  
  }
	}
}