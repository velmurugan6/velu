package beginner;

import java.io.IOException;
import java.util.Scanner;

public class metre {

	private static Scanner read;

	public static void main(String[] args) throws IOException{
		
		int n;
		do
		{
			System.out.println("Enter the option:\n1.Centimetre to meter\n2.Meter to Centimeter\n3.Meter to Kilometre\n4.Miles to kilometre\n5.Quit ");
			read = new Scanner(System.in);
			n= read.nextInt();
			switch(n)
			{
			case 1:
				System.out.println("Enter the Centimetre");
				float centi=read.nextFloat();
				System.out.println("Meter="+centi/100);
				break;
				
			case 2:
				System.out.println("Enter the Meter");
				int met=read.nextInt();
				System.out.println("Centimeter="+met*100);
				break;
				
			case 3:
				System.out.println("Enter the Meter");
				int net=read.nextInt();
				System.out.println("Kilometer="+net/1000);
			    break;
			    
			case 4:
				System.out.println("Enter the Miles");
			    float mil=read.nextFloat();
			    System.out.println("Kilometer="+mil/1.6);
			    break;
			   
			}
			
			}while(n<5);
	}

}
