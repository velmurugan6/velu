package beginner;
import java.util.*;

public class Name {
	public static void main(String args[])

    {
    Scanner name=new Scanner(System.in);
    System.out.println("\nEnter the name \n");
    String word=name.nextLine();
    int n=word.length();
    System.out.println("\nLength of the name \n"+n);

int i=0;
		do
		{  
         int j=0;
             while(j<(5-i))
             {
        	 System.out.print("");
        	 j++;
             }
             int k=0;
             while(k<=i)
             {
            	 char c = word.charAt(k);
            	 System.out.print(c+" ");
        	 k++;
             }
             System.out.println("");
		 i++;
    }while(i<n);

}

}
