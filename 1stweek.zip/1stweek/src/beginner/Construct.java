package beginner;

public class Construct {
	Construct()
	{
	System.out.println("I am a constructor");	
	}
	void show()
	{
		System.out.println("sadfsadfds");
	}

	public static void main(String[] args) {
		Construct mac =new Construct();
         mac.show();
	}

}
