package beginner;

import java.io.*;
import java.util.*;

class Hashmap {
	public static void main(String args[]) throws IOException {

		HashMap<Integer, String> hashmap = new HashMap<Integer, String>();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter number");
		int n1 = Integer.parseInt(br.readLine());
		try {
			int i = 1;
			while (i <= n1) {
				System.out.println("Enter key");
				int n = Integer.parseInt(br.readLine());
				System.out.println("Enter Name ");
				String s = br.readLine();
				hashmap.put(n, s);
				i++;
			}
			int a = 0;
			do {
				System.out
						.println("\n enter your option\n 1. print hashmap\n 2. find person through key\n 3. insert or replace values\n 4. exit");
				a = Integer.parseInt(br.readLine());
				switch (a) {
				case 1: {
					for (Map.Entry<Integer, String> m : hashmap.entrySet()) {
						System.out.println(m.getKey() + " " + m.getValue());
					}
					break;
				}
				case 2: {
					System.out.println("enter the key to find");
					int b = Integer.parseInt(br.readLine());
					System.out.println("Values at key " + b + " is:"
							+ hashmap.get(b));
					break;
				}
				case 3: {
					System.out.println("enter the key to insert or replace");
					int c = Integer.parseInt(br.readLine());
					System.out.println("Enter Name ");
					String t = br.readLine();
					hashmap.put(c, t);
					for (Map.Entry<Integer, String> m : hashmap.entrySet()) {
						System.out.println(m.getKey() + " " + m.getValue());
					}
					break;
				}
				case 4:
					break;
				}
			} while (a <= 3);
		} catch (Exception e) {
			System.out.println("Enter valid response only");

		}
	}
}
