package beginner;

import java.util.Scanner;

public class Factorial {
    private static Scanner read;
	int fact(int get)
    {
    	int answer;
    	if(get<=1)
    		return 1;
    	
    	answer= fact(get-1)*get;
    	return answer;
    }
	public static void main(String[] args) {
	Factorial obj=new Factorial();
	System.out.println("Enter the number to factorial");
	read = new Scanner(System.in);
	int get=read.nextInt();
	System.out.println("The Factorial is "+obj.fact(get));
	int set=read.nextInt();
	System.out.println("The factorial is"+obj.fact(set));


	}

}
