package beginner;

import java.util.Scanner;

public class Str {

	public static void main(String[] args) {
		String name, name2;
		Scanner n1=new Scanner(System.in);
		name=n1.nextLine();
		name2=n1.nextLine();
		name=name.toUpperCase();
		name2=name2.toUpperCase();

		char[] ch=name.toCharArray();
		char[] ch2=name2.toCharArray();
		int n=ch.length;
		int m=ch2.length;
		
		System.out.println();
		for(int i=0;i<ch.length;i++)
		{
		for(int j=0;j<ch2.length;j++)
		{
		if (ch[i]==ch2[j]){
		ch[i]=' ';
		ch2[j]=' ';
		
		}
		}
		}
		
		System.out.print(ch);
		System.out.println();
		System.out.print(ch2);
		System.out.println();

		String wer=ch.toString();
		String wer2=ch2.toString();
		n1.close();
		
		}
	}

