package beginner;

public class Square {
	public void area()
	{
		int a=10;
		System.out.println("Area of Square is "+a*a);
	}
	public static void main(String args[])
	{
		Square sq=new Square();
		Rectangle re=new Rectangle();
		Triangle tr=new Triangle();
		sq.area();
		re.area();
		tr.area();
	}

}
class Rectangle extends Square
{
	public void area()
	{
		int a=10,b=20;
		System.out.println("Area of Rectangle is "+a*b);
	}
}
class Triangle extends Square
{
	public void area()
	{
		float a=10,b=20;
		System.out.println("Area of Triangle is "+0.5*(a*b));
	}
}