package beginner;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Hash {
	
	public static void main(String[] args) {
	//HashMap student=new HashMap();
	int n;
	String name;
	HashMap<String,Long> reg=new HashMap<String,Long>();
	long num;
	System.out.println("Enter the no.of students:");
	Scanner stu=new Scanner(System.in);
	n=stu.nextInt();
	for(int i=1;i<=n;i++)
	{
	System.out.println("Enter the students name:");
	name=stu.nextLine();
	
	System.out.println("Enter the students num:");
	num=stu.nextLong();
	reg.put(name,num);
	System.out.println("Roll num "+i+". "+(name)+" "+num);
	}
	for(Map.Entry detail:reg.entrySet()){
	System.out.println(detail.getKey()+""+detail.getValue()+""+detail.getValue());
	
	}
	stu.close();
	}}


