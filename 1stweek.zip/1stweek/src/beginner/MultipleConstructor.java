package beginner;

public class MultipleConstructor {
	String name;
	int age;
	

	public static void main(String[] args) {
	   new MultipleConstructor("Bala",21);
	   new MultipleConstructor(21);
	   new MultipleConstructor("Bala");


	};
	
	

	public MultipleConstructor(String a,int b)
	{
		name= a;
		age=b;
		System.out.println("Name & Age: "+name+" and "+age);
	}
	public MultipleConstructor(int b)
	{
		age=b;
		System.out.println("age:"+age);

	}
	public MultipleConstructor(String a)
	{
		name=a;
		System.out.println("Name:"+name);

	}

}
